exp=require("express")
router=exp.Router()

router.post("/ins_product",function(req,res){
    pbody=req.body;
    aid=1
    con.tbl_product.find({},{_id:1}).sort({_id:-1}).limit(1,function(err,result){
        if(result.length==0)
         aid=1;
         else{
         aid=result[0]._id
         aid++
        }
        console.log(aid)
         pbody._id=aid;
         pbody.active=1
         con.tbl_product.createIndex({brandname:1,productname:1},{unique:1},function(err1,result1){
            if(err1)
            res.send(err1)
            else
            con.tbl_product.save(pbody,function(err,result){
            if(err)
            res.send(err)
            else
            res.send("Inserted")
          })
       })
    }) 
})


router.get("/get_product",function(req,res){
    con.tbl_product.find(function(err,result){
        con.tbl_subsubcat.find(function(e,result2){
            con.tbl_subcat.find(function(er,result3){
                con.tbl_cat.find(function(err,result4){
                    con.tbl_brand.find(function(err,result5){
            for(i=0;i<result.length;i++)
            {
                for(j=0;j<result2.length;j++)
                {
                   if(result[i].subsubcatid==result2[j]._id)
                   {
                       result[i].subsubcatname=result2[j].subsubcatname
                      
                       for(k=0;k<result3.length;k++){
                        if(result[i].subcatid==result3[k]._id){
    
                           result[i].subcatname=result3[k].subcatname

                           for(l=0;l<result4.length;l++)
                           {
                               if(result[i].catid==result4[l]._id)
                                result[i].catname=result4[l].cn
                           }
                           for(m=0;m<result5.length;m++)
                           {
                               if(result[i].brandid==result5[m]._id)
                                result[i].brandname=result5[m].brandname
                           }
                        }
                     }
                   }  
                }  
            }
            res.send(result)
               })
            })
         })
      }) 
   })
})

router.post("/update",function(req,res){
    //console.log(req.body)
    con.tbl_product.update(req.body[0],req.body[1],req.body[2],function(err,result){
        if(err)
        res.send(err)
        else
        res.send("Updated")
    })
})

module.exports=router