exp=require("express")
router=exp.Router()

router.post("/ins_subsub_cat",function(req,res){
    reqbody=req.body
    lid=1
con.tbl_subsubcat.find({},{_id:1}).sort({_id:-1}).limit(1,function(err,resu){
    if(resu.length==0)
    lid=1;
    else
    {
lid=resu[0]._id
lid++
    }
console.log(lid)
reqbody._id=lid
reqbody.active=1
con.tbl_subsubcat.createIndex({subcatname:1,subsubcatname:1},{unique:1},function(err1,result1){
    if(err1)
    res.send(err1)
    else
    con.tbl_subsubcat.save(reqbody,function(err,result){
    if(err)
    res.send(err)
    else
    res.send("Inserted")
})
})
})
})
router.get("/get_subsubcat",function(req,res){

    con.tbl_subsubcat.find(function(err,result){
    con.tbl_subcat.find(function(err1,result1){
    con.tbl_cat.find(function(err,result2){

    
        for(i=0;i<result.length;i++)
        {
            for(j=0;j<result1.length;j++)
            {
                if(result[i].subcatid==result1[j]._id)
                {
                result[i].subcatname=result1[j].subcatname
               
                for(k=0;k<result2.length;k++) {
                    
                   if(result[i].catid==result2[k]._id)
                   result[i].catname=result2[k].cn 
                }
            }
           }
         }
        res.send(result)
      })
    })
  })
})
router.post("/update",function(req,res){
    //console.log(req.body)
    con.tbl_subsubcat.update(req.body[0],req.body[1],function(err,result){
        if(err)
        res.send(err)
        else
        res.send("Updated")
    })
})
// router.post("/subsubget_cat",function(req,res){
//     con.dbsubsubcat.find(req.body,function(err,result){
//         if(err)
//         res.send(err)
//         else
//         res.send(result)
//     })
// })
module.exports=router