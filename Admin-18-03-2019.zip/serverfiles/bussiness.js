exp=require("express")
router=exp.Router()
/////Insert
router.post("/getbus1",function(req,res){
bdata=req.body
con.tbl_order_info.find({date:{ $regex:bdata.dt}},function(err,result){
res.send(result)
console.log(result)
})
})

router.post("/getorders",function(req,res){
    bdata=req.body
    console.log(bdata.order_id)
    con.tbl_order_details.find({order_id:bdata.order_id},function(err,result){
    res.send(result)
    console.log(result)
    })
    
    })


module.exports=router
