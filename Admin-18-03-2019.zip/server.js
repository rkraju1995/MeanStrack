exp=require("express")
bp=require("body-parser")
expfiles=require("express-fileupload")
app=exp()
app.use(bp.json())
app.use(expfiles())
catfile=require("./serverfiles/cat")
brandfile=require("./serverfiles/brand")
productfile=require("./serverfiles/product")
subcatfile=require("./serverfiles/subcat")
subsubcatfile=require("./serverfiles/subsubcat")
bussinessfile=require("./serverfiles/bussiness")
mj=require("mongojs")
con=mj("mongodb://raju:raju1234@ds253203.mlab.com:53203/rk-db")

app.use("/cat_ref",catfile)
app.use("/brand_ref",brandfile)
app.use("/subcat_ref",subcatfile)
app.use("/subsubcat_ref",subsubcatfile)
app.use("/product_ref",productfile)
app.use("/bus_ref",bussinessfile)
app.listen(1234)



//----upload images-------//
app.post("/upload",function(req,res){
    iname1=req.files.f1.name;
    iname2=req.files.f2.name;
    iname3=req.files.f3.name;
    iref1=req.files.f1;
    iref2=req.files.f2;
    iref3=req.files.f3;
    dt=new Date()
    dt=dt/1000
    iname1="img"+parseInt(dt)+"_"+iname1
    iref1.mv("src/assets/prodimages/"+iname1)
    iname2="img"+parseInt(dt)+"_"+iname2
    iref2.mv("src/assets/prodimages/"+iname2)
    iname3="img"+parseInt(dt)+"_"+iname3
    iref3.mv("src/assets/prodimages/"+iname3)
    con.tbl_product.find({},{_id:1}).sort({_id:-1}).limit(1,function(err,result){
        newid=result[0]._id
        con.tbl_product.update({_id:newid},{$set:{pimages:[iname1,iname2,iname3]}})
        res.redirect("http://localhost:12345/product")
    })
})
