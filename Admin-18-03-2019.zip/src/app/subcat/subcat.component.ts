import { Component, OnInit, Inject } from '@angular/core';
import {Http} from "@angular/http"
@Component({
  selector: 'app-subcat',
  templateUrl: './subcat.component.html',
  styleUrls: ['./subcat.component.css']
})
export class SubcatComponent implements OnInit {

  constructor(@Inject(Http) public ht) { }
  var_cat_data;var_subcat_data;var_edit_cat_id
  var_drp_cat="";var_sub_cat;tmp=0;var_edit_subcat_name;
  var_subcat_active_data;
  order="subcatname";ordervar;pag1=1
  funorder(ord){
    this.order=ord;
    this.ordervar=!this.ordervar;
  }
  ngOnInit() {
    this.ht.get("subcat_ref/get_subcat").subscribe(dt=>{
      this.var_subcat_data=JSON.parse(dt._body)
    })
    this.ht.get("cat_ref/get_cat").subscribe(dt=>{
      this.var_cat_data=JSON.parse(dt._body)
    })
  }
  funsave(){
    var obj1={_id:this.tmp}
    var obj2={subcatname:this.var_edit_subcat_name,catid:this.var_edit_cat_id,active:this.var_subcat_active_data}
    var arr=[obj1,obj2]
    this.ht.post("subcat_ref/update",arr).subscribe(st=>{
      alert(st._body)
      this.tmp=0
      this.ht.get("subcat_ref/get_subcat").subscribe(dt=>{
        this.var_subcat_data=JSON.parse(dt._body)
      })
    })
  }
  funedit(i){
    //console.log(i)
    this.tmp=i._id
    this.var_edit_subcat_name=i.subcatname
    this.var_edit_cat_id=i.catid
    this.var_subcat_active_data=i.active
  }
  fun_ins_sub_cat(){
    var obj={subcatname:this.var_sub_cat,catid:this.var_drp_cat,}
    this.ht.post("subcat_ref/ins_sub_cat",obj).subscribe(dt=>{
      alert(dt._body)
      this.tmp=0
    this.ht.get("subcat_ref/get_subcat").subscribe(dt=>{
    this.var_subcat_data=JSON.parse(dt._body)
    })
  })
 }
}
