import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule} from "@angular/router"
import { AppComponent } from './app.component';
import {NgxPaginationModule} from 'ngx-pagination'
import {OrderModule} from 'ngx-order-pipe'
import {Ng2SearchPipeModule} from 'ng2-search-filter'
import { CatComponent } from './cat/cat.component';
import { SubcatComponent } from './subcat/subcat.component';
import { SubsubcatComponent } from './subsubcat/subsubcat.component';
import {FormsModule} from "@angular/forms"
import {HttpModule} from "@angular/http";
import { BrandComponent } from './brand/brand.component';
import { ProductComponent } from './product/product.component';
import { BussinessComponent } from './bussiness/bussiness.component';
import { DateOrdersComponent } from './date-orders/date-orders.component'

var robj=[{
  path:"",component:CatComponent
},{path:"cat",component:CatComponent},{
  path:"subcat",component:SubcatComponent
},{
  path:"subsubcat",component:SubsubcatComponent
},{
  path:"brand",component:BrandComponent
},{
  path:"product",component:ProductComponent
},{
  path:"bussiness",component:BussinessComponent
},{
  path:"orders",component:DateOrdersComponent
}]
@NgModule({
  declarations: [
    AppComponent,
    CatComponent,
    SubcatComponent,
    SubsubcatComponent,
    BrandComponent,
    ProductComponent,
    BussinessComponent,
    DateOrdersComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(robj),FormsModule,HttpModule,
    NgxPaginationModule,OrderModule,Ng2SearchPipeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
