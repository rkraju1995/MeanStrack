import { Component, OnInit ,Inject} from '@angular/core';
import {Http} from "@angular/http"

@Component({
  selector: 'app-subsubcat',
  templateUrl: './subsubcat.component.html',
  styleUrls: ['./subsubcat.component.css']
})
export class SubsubcatComponent implements OnInit {
  tmp:any;txt3
  var_cat_data;var_subcat_data;var_subsubcat_data;;show_sub_cat_data
  var_drp_cat="";var_drp_subcat;var_subsub_cat;

  var_edit_subsubcat_name;var_edit_cat_id;var_edit_subcat_id
  var_subsubcat_active_data;
  
  constructor(@Inject(Http) public ht) { }
 
  ngOnInit() {
   this.ht.get("cat_ref/get_cat").subscribe(dt=>{
     this.var_cat_data=JSON.parse(dt._body)
   })
   this.ht.get("subcat_ref/get_subcat").subscribe(dt=>{
     this.var_subcat_data=JSON.parse(dt._body)
   })
    this.ht.get("subsubcat_ref/get_subsubcat").subscribe(dt=>{
       this.var_subsubcat_data=JSON.parse(dt._body);
    })
  }
  
  order="subsubcatname";ordervar;pag2=1
  funorder(ord){
    this.order=ord;
    this.ordervar=!this.ordervar;
  }
 
  fun_cat_change(){
    this.var_drp_subcat=""
    this.show_sub_cat_data=[]
    for(var i=0;i<this.var_subcat_data.length;i++)
    {
     if(this.var_subcat_data[i].catid==this.var_drp_cat){
       var obj={_id:this.var_subcat_data[i]._id,subcatname:this.var_subcat_data[i].subcatname}
       this.show_sub_cat_data.push(obj)
     }
    }
  }
  fun_ins_subsub_cat(){
    var obj={subsubcatname:this.var_subsub_cat,catid:this.var_drp_cat,subcatid:this.var_drp_subcat}
    this.ht.post("subsubcat_ref/ins_subsub_cat",obj).subscribe(dt=>{
    alert(dt._body)
    this.tmp=0
    this.ht.get("subsubcat_ref/get_subsubcat").subscribe(dt=>{
      this.var_subsubcat_data=JSON.parse(dt._body);
   })
  })
  }
  funedit(z){
    //console.log(i)
    this.tmp=z._id
    this.var_edit_subsubcat_name=z.subsubcatname
    this.var_edit_cat_id=z.catid
    this.var_edit_subcat_id=z.subcatid
    this.var_subsubcat_active_data=z.active
  }
  funsave(){  
    var obj1={_id:this.tmp}
    var obj2={subsubcatname:this.var_edit_subsubcat_name,catid:this.var_edit_cat_id,subcatid:this.var_edit_subcat_id,active:this.var_subsubcat_active_data}
    var arr=[obj1,obj2]
    this.ht.post("subsubcat_ref/update",arr).subscribe(st=>{
      alert(st._body)
      this.tmp=0
      this.ht.get("subsubcat_ref/get_subsubcat").subscribe(dt=>{
        this.var_subsubcat_data=JSON.parse(dt._body)
      })
    })
  }

}
