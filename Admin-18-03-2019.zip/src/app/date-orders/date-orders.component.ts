import { Component, OnInit, Inject } from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import {Http} from '@angular/http';

@Component({
  selector: 'app-date-orders',
  templateUrl: './date-orders.component.html',
  styleUrls: ['./date-orders.component.css']
})

export class DateOrdersComponent implements OnInit {
order_id;
var_order_data;
  constructor(public ar:ActivatedRoute,@Inject(Http) public ht) { }

  fungetorder(orderid){
    this.ht.post("bus_ref/getorders",{order_id:orderid}).subscribe(dt=>{
      this.var_order_data=JSON.parse(dt._body)
      alert(this.var_order_data)
    })
  }

  ngOnInit() {
    this.ar.params.subscribe(dt=>{
      this.order_id=dt["order_id"]
      alert(this.order_id)
      this.fungetorder(this.order_id)
    })
  }

}
