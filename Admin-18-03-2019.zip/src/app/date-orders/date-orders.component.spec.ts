import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DateOrdersComponent } from './date-orders.component';

describe('DateOrdersComponent', () => {
  let component: DateOrdersComponent;
  let fixture: ComponentFixture<DateOrdersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DateOrdersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DateOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
