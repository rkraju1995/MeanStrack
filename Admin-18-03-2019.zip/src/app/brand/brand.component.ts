import { Component, OnInit,Inject } from '@angular/core';
import {Http} from "@angular/http"
@Component({
  selector: 'app-brand',
  templateUrl: './brand.component.html',
  styleUrls: ['./brand.component.css']
})
export class BrandComponent implements OnInit {
  constructor(@Inject (Http) private ht) { }
  txtbrand;txt3
    ngOnInit() {
      this.funget()
    }
    tmp=0;selbrandname;drpstatus;pag3=1;ordvar;or="brandname"
    funord(ord){
      this.or=ord;
      this.ordvar=!this.ordvar;
    }
    funedit(selbranddt){
   this.tmp=selbranddt._id
   this.selbrandname=selbranddt.brandname
   this.drpstatus=selbranddt.active
    }
    funsave(){
      this.ht.post("brand_ref/update",[{_id:this.tmp},{brandname:this.selbrandname,active:this.drpstatus}]).subscribe(dt=>{
        alert(dt._body)
        this.tmp=0
        this.funget()
      })
    }
    funins(){
      this.ht.post("brand_ref/insert_brand",{brandname:this.txtbrand}).subscribe(dt=>{
        alert(dt._body)
        this.funget()
      })
    }
    brand_data
   funget(){
     this.ht.get("brand_ref/get_brand").subscribe(dt=>{
       //alert(dt)
      this.brand_data=JSON.parse(dt._body)
     })
   }
  }