import { Component, OnInit, Inject } from '@angular/core';
import {Http} from "@angular/http"
@Component({
  selector: 'app-cat',
  templateUrl: './cat.component.html',
  styleUrls: ['./cat.component.css']
})
export class CatComponent implements OnInit {

  constructor(@Inject (Http) private ht) { }
txtcat
  ngOnInit() {
    this.funget()
  }
  tmp=0;selcatname;drpstatus;pag=1;ordvar;or="cn"
  funord(ord){
    this.or=ord;
    this.ordvar=!this.ordvar;
  }
  funedit(selcatdt){
 this.tmp=selcatdt._id/////When ever we click on edit button we aer assign the tmp value to _id value////
 this.selcatname=selcatdt.cn
 this.drpstatus=selcatdt.active
 //alert(this.drpstatus)
  }
  funsave(){
    this.ht.post("cat_ref/update",[{_id:this.tmp},{cn:this.selcatname,active:this.drpstatus}]).subscribe(dt=>{
      alert(dt._body)
      this.tmp=0
      this.funget()
    })
  }
  funins(){
    this.ht.post("cat_ref/insert_cat",{cn:this.txtcat}).subscribe(dt=>{
      alert(dt._body)
      this.funget()
    })
  }
  cat_data
 funget(){
   this.ht.get("cat_ref/get_cat").subscribe(dt=>{
     //alert(dt)
    this.cat_data=JSON.parse(dt._body)
   })
 }
}
