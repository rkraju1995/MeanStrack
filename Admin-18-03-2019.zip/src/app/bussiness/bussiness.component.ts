import { Component, OnInit, Inject } from '@angular/core';
import {Http} from "@angular/http";
declare var $:any
@Component({
  selector: 'app-bussiness',
  templateUrl: './bussiness.component.html',
  styleUrls: ['./bussiness.component.css']
})
export class BussinessComponent implements OnInit {
orderhistory
  constructor(@Inject(Http) public ht) { }
funget(sdt){
  alert(sdt)
  this.ht.post("bus_ref/getbus1",{dt:sdt}).subscribe(st=>{
    alert("Hi")
    this.orderhistory=JSON.parse(st._body)
  })
}
  ngOnInit() {
    $("document").ready(()=>{
      $("#div1").datepicker({
        dateFormat:"yy-mm-dd",
        onSelect:(dt)=>{
          this.funget(dt)
        }
      })
    })
  }

}
