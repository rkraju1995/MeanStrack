import { Component, OnInit, Inject } from '@angular/core';
import {Http} from '@angular/http';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor(@Inject(Http) public ht) { }
  
  tmp=0;                 ////Reference variable/////
  txt4;                 ////For Search Module//////  

  var_cat_data;          ////Category data////
  var_subcat_data;       ////Subcategory data/////
  var_subsubcat_data;    ////Subsubcategory data/////
  var_brand_data;        ////brand data///// 
  var_product_data;      ////product data////

  var_drp_cat="";           ////Category dropdown variable/////
  var_drp_subcat;        ////Subcategory dropdown variable/////
  var_drp_subsubcat;     ////Subsubcategory dropdown variable/////
  var_drp_brand="";         ////Brand dropdown variable/////

  show_subcat_data;      ////Display of Subcat variable/////
  show_subsubcat_data;   ////Display of Subsubcat variable/////

  var_pro                ////Variable which was binding textbox/////
  var_pro_qty            ////Variable which was binding Quantity textbox/////    
  var_pro_price          ////Variable which was binding Price textbox///// 
  var_pro_desc          ////Variable which was binding description textbox/////
  var_pro_color         ////Variable which was binding color textbox/////  
  var_pro_type          ////Variable which was binding type textbox/////
  var_pro_rating        ////Variable which was binding rating textbox/////
  var_pro_offer         ////Variable which was binding offer textbox/////
  
  var_edit_product_name  ////Edit templet binding variable for products/////
  var_edit_cat_id        ////Edit templet binding variable for category/////
  var_edit_subcat_id     ////Edit templet binding variable for Subcategory/////
  var_edit_subsubcat_id  ////Edit templet binding variable for Subsubcategory/////
  var_edit_brand_id      ////Edit templet binding variable for brand/////
  var_edit_product_qty   ////Edit templet binding variable for products quantity/////
  var_edit_product_type   ////Edit templet binding variable for products type/////
  var_edit_product_color  ////Edit templet binding variable for products color/////
  var_edit_product_rating ////Edit templet binding variable for products rating/////
  var_edit_product_offer  ////Edit templet binding variable for products offer/////
  var_edit_product_desc   ////Edit templet binding variable for products description/////
  var_edit_product_price   ////Edit templet binding variable for products Price/////
  var_product_active_data////Edit templet binding variable for Product Active/////


  ngOnInit() {
    this.ht.get("cat_ref/get_cat").subscribe(dt=>{
      this.var_cat_data=JSON.parse(dt._body);
    })
    this.ht.get("subcat_ref/get_subcat").subscribe(dt=>{
      this.var_subcat_data=JSON.parse(dt._body)
    })
    this.ht.get("subsubcat_ref/get_subsubcat").subscribe(dt=>{
      this.var_subsubcat_data=JSON.parse(dt._body)
    })
    this.ht.get("brand_ref/get_brand").subscribe(dt=>{
      this.var_brand_data=JSON.parse(dt._body)
    })
    this.ht.get("product_ref/get_product").subscribe(dt=>{
      this.var_product_data=JSON.parse(dt._body)
    })
  }
  
  order="productname";ordervar;pag3=1
  funorder(ord){
    this.order=ord;
    this.ordervar=!this.ordervar;
  }
 
  
  fun_pro_cat_change(){
     this.var_drp_subcat=""
     this.show_subcat_data=[]
     for(var i=0;i<this.var_subcat_data.length;i++)
     {
      if(this.var_subcat_data[i].catid==this.var_drp_cat){
        var obj={_id:this.var_subcat_data[i]._id,subcatname:this.var_subcat_data[i].subcatname}
        this.show_subcat_data.push(obj)
      }
     } 
    }
    
    fun_pro_subcat_change(){
      this.var_drp_subsubcat=""
      this.show_subsubcat_data=[]
      for(var j=0;j<this.var_subsubcat_data.length;j++)
      {
         if(this.var_subsubcat_data[j].subcatid==this.var_drp_subcat){
          var obj1={_id:this.var_subsubcat_data[j]._id,subsubcatname:this.var_subsubcat_data[j].subsubcatname}
          this.show_subsubcat_data.push(obj1) 
        }
      }
    }

    fun_ins_products(){
      var obj={productname:this.var_pro,productprice:this.var_pro_price,productqty:this.var_pro_qty,
               catid:this.var_drp_cat,subcatid:this.var_drp_subcat,productdesc:this.var_pro_desc,
               productcolor:this.var_pro_color,producttype:this.var_pro_type,
               productrating:this.var_pro_rating,productoffer:this.var_pro_offer, 
               subsubcatid:this.var_drp_subsubcat,brandid:this.var_drp_brand}
      this.ht.post("product_ref/ins_product",obj).subscribe(dt=>{
      alert(dt._body)
      //this.tmp=0
      var imgins =<HTMLFormElement>document.getElementById("frm")
        imgins.submit()
     // this.ht.get("product_ref/get_product").subscribe(dt=>{
      //  this.var_product_data=JSON.parse(dt._body)
      //})
    })
    }
    funedit(i){
      //console.log(i)
      this.tmp=i._id
      this.var_edit_product_name=i.productname
      this.var_edit_brand_id=i.brandid
      this.var_edit_product_price=i.productprice
      this.var_edit_product_color=i.productcolor
      this.var_edit_product_type=i.producttype
      this.var_edit_product_desc=i.productdesc
      this.var_edit_product_qty=i.productqty
      this.var_edit_product_rating=i.productrating
      this.var_edit_product_offer=i.productoffer
      this.var_edit_cat_id=i.catid
      this.var_edit_subcat_id=i.subcatid
      this.var_edit_subsubcat_id=i.subsubcatid
      this.var_product_active_data=i.active 
    }
    
    funsave(){
      var obj1={_id:this.tmp};
      var obj2={productname:this.var_edit_product_name,
                brandid:this.var_edit_brand_id,
                productprice:this.var_edit_product_price,
                productcolor:this.var_edit_product_color,
                producttype:this.var_edit_product_type,
                productdesc:this.var_edit_product_desc,
                productqty:this.var_edit_product_qty,
                productrating:this.var_edit_product_rating,
                productoffer:this.var_edit_product_offer,
                catid:this.var_edit_cat_id,
                subcatid:this.var_edit_subcat_id,
                subsubcatid:this.var_edit_subsubcat_id,
                active:this.var_product_active_data}
      var arr=[obj1,obj2]          
      this.ht.post("product_ref/update",arr).subscribe(dt=>{
        alert(dt._body)
        this.tmp=0;
        this.ht.get("product_ref/get_product").subscribe(dt=>{
          this.var_product_data=JSON.parse(dt._body)
        })
      })
    } 


}
