exp=require("express")
router=exp.Router()

var sql = require("mssql");

var config = {
    user: 'dev', 
    password: '123456',
    server: 'TLIHYDDT128\\SQLEXPRESS', 
    database: 'LeadNext' ,
    port : 1433
};

router.post('/getdata', function (req, res) {
    rbody=req.body.x
    //console.log(rbody)
    sql.close()
    // connect to your database
    sql.connect(config, function (err) {
    
        if (err) console.log(err);

        // create Request object
        var request = new sql.Request();
           
        // query to the database and get the records  
        request.query("select DISTINCT (CompanyName) CompanyName,linkedin,BDMName from contact_address_leadsTli where BDMName='" + rbody + "'", function (err, result) {
            //debugger;
            //console.log(result)
            if (err) console.log(err)

            // send records as a response
            res.send(result);
            
        });
    });
});


router.post('/getbycompany', function (req1, res1) {
    rbody=req1.body
    companyname=rbody.companyname
    bdmname=rbody.bdmname
    // console.log(companyname)
    // console.log(bdmname)


        var request = new sql.Request();
         
            request.query("select CONCAT(contact_first_name , ' ', contact_last_name) as FullName,ID,CompanyName,BDMName,Designation,EmailId,phone1,Ext,cdate from contact_address_leadsTli where contact_first_name is not null and contact_last_name is not null and CompanyName='" + companyname + "'and bdmname ='"+bdmname+"' and (Status<>'DNC' or Status is null) Order by cdate desc"  , function (err1, result1) {
           //request.query("select count(*),ID,CompanyName,Designation,EmailId,contact_first_name,contact_last_name,phone1,Ext,cdate from contact_address_leadsTli where contact_first_name is not null and contact_last_name is not null and CompanyName='" + rbody + "'Group by ID,CompanyName,Designation,EmailId,contact_first_name,contact_last_name,phone1,Ext,cdate Order by cdate desc"  , function (err1, result1) {
           
            if (err1) console.log(err1)

            res1.send(result1);

        });
 });

module.exports=router