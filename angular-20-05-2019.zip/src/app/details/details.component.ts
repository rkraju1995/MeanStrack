import { Component, OnInit ,enableProdMode } from '@angular/core';
import {RestService} from "../rest.service";
import {Router} from "@angular/router"
import * as _ from 'lodash';

enableProdMode();

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  data;
  username=localStorage.getItem("username")

  constructor(public rs:RestService,public rt:Router) { 
  }
  
  newdata////for company details
  companyname//// company name from grid
  contacts//// contact data 
  leads//// leads data
  bdmname
  contact;
  dropdownstatus;
  contactid
  contactfirstname
  contactlastname
  contactstatus
  contactbdmname
  contactcompanyname
  public dropDown: Array<any> = [
    {value:'DNC'}
    //{ text: "DNC", value: "DNC" }
  ];
  
  
  ngOnInit() {
    this.rs.getuserdata(this.username).subscribe(dt=>{
      this.data=dt;
       this.newdata= this.data.recordsets[0]
       this.newdata= _.uniqBy(this.newdata,'CompanyName','linkedin');
      })
    }

    gridUserSelectionChange(gridUser,selection) {
      //let selectedData = gridUser.data.data[selection.index];
      const selectedData = selection.selectedRows[0].dataItem;
      // alert(JSON.stringify(selectedData))
      this.companyname=selectedData.CompanyName
      this.bdmname=selectedData.BDMName
       //alert(JSON.stringify(this.companyname))
        this.fungetcompany();
        this.fungetleads();
    }

    contactUserSelectionChange(selection){  
      const selectedData = selection.selectedRows[0].dataItem;
      //this.contact =selectedData.FullName
      alert(JSON.stringify(selectedData))
      //alert(JSON.stringify(this.dropDownData))
    }
     
    onChange(data){
      //alert(JSON.stringify(data))
      this.dropdownstatus=data
      this.contactid=this.dropdownstatus.ID
      this.contactlastname=this.dropdownstatus.FullName
      this.contactbdmname=this.dropdownstatus.BDMName
      this.contactcompanyname=this.dropdownstatus.CompanyName
      this.contactlastname=this.contactlastname.split(" ");
      if(this.contactlastname[2]==undefined){
        this.contactfirstname=this.contactlastname[0]
        this.contactlastname=this.contactlastname[1]
        }else{
        this.contactfirstname=this.contactlastname[0]+" "+this.contactlastname[1]
        this.contactlastname=this.contactlastname[2]
        } 
        this.contactstatus=this.dropdownstatus.status.value
        var obj ={id:this.contactid,firstname:this.contactfirstname,lastname:this.contactlastname,status:this.contactstatus,bdmname:this.contactbdmname,companyname:this.contactcompanyname}
        //alert(JSON.stringify(obj))
        this.rs.changeStatusDnc(obj).subscribe(dt=>{
          //alert("Status Updated")
          this.fungetcompany()
        })

    }

    userLogout(){
      localStorage.clear(),
      location.href="http://localhost:4200"
      this.rt.navigateByUrl("")
    }

     fungetcompany(){
      var company={companyname:this.companyname,bdmname:this.bdmname}
       this.rs.getcompany(company).subscribe(dt=>{
         this.contacts=dt
         this.contacts=this.contacts.recordsets[0]
        //  this.contacts = Math.max.apply(Math, this.contacts.map(o=>{ return o.cdate}))
         //  this.contacts=this.contacts.sort((a,b) => a.cdate.rendered.localeCompare(b.cdate.rendered));
         //this.contacts=this.contacts.sort((a,b)=>a.cdate.rendered > b.cdate.rendered)
         this.contacts= _.uniqBy(this.contacts, 'FullName','Designation','phone1','Ext','EmailId','cdate'); 
         //  this.contacts.push({ text: "DNC", value: "DNC" })
         //alert(JSON.stringify(this.contacts))
       })
     }

    fungetleads(){
      var leads={companyname:this.companyname,bdmname:this.bdmname}
      this.rs.getleads(leads).subscribe(dt=>{
        this.leads=dt
        this.leads=this.leads.recordsets[0]
        this.leads= _.uniqBy(this.leads,'Position','Location','Status','linkedin','jobDescription','Ctype','TimeZone');
        //alert(JSON.stringify(this.leads))
        })
    }

  }
