import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { DetailsComponent } from './details/details.component';
import { LoginComponent } from './login/login.component';

import {HttpClientModule} from "@angular/common/http";
import {FormsModule} from "@angular/forms";
import { ReactiveFormsModule } from '@angular/forms';
import {RouterModule,Routes} from "@angular/router";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations"
import {MatInputModule} from "@angular/material/input"
import {MatAutocompleteModule} from "@angular/material/autocomplete";

import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { PopupModule } from '@progress/kendo-angular-popup';
import { InputsModule } from '@progress/kendo-angular-inputs';

const routes: Routes = [
  { path: 'details', component:DetailsComponent},
  { path: 'login', component:LoginComponent},
  { path: '', component:LoginComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    DetailsComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,FormsModule,RouterModule.forRoot(routes),
    BrowserAnimationsModule,MatInputModule,MatAutocompleteModule, GridModule, ButtonsModule,DropDownsModule,
    PopupModule,InputsModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
