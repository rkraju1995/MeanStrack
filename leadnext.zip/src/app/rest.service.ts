import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import {map} from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class RestService {

  constructor(public ht:HttpClient) { }

  public dt(res:Response){
    return res
  }

   UserLoginService(userData):Observable<any>{
    //alert(JSON.stringify(userData))
    return(this.ht.post("loginref/userlogin",userData).pipe(map(this.dt)))
  }

  getuserdata(uname):Observable<any>{
    //alert(uname)
    return(this.ht.post("detailsref/getdata",{x:uname}).pipe(map(this.dt)))
  }

  getcompany(cmpname):Observable<any>{
    //alert(cmpname)
    return(this.ht.post("detailsref/getbycompany",{y:cmpname}).pipe(map(this.dt)))
  }

  getleads(name):Observable<any>{
    //alert(name)
    return(this.ht.post("leadsref/getbyleads",{z:name}).pipe(map(this.dt)))
  }
  
}
