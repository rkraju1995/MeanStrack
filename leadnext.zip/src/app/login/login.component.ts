import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'
import {RestService} from '../rest.service'
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username;password
  constructor(public rs:RestService,public rt:Router) { }

  funpost(){
    // this.rs.getuserdata(this.username).subscribe(dt=>{
    //   localStorage.setItem("username",this.username)
    //   this.rt.navigateByUrl("details")
    // })
    var details={username:this.username,password:this.password}
    this.rs.UserLoginService(details).subscribe(dt=>{
      if(dt.tot==0)
      alert("Invalid username/password")
      else
      {
        localStorage.setItem("uid",dt.username)
        localStorage.setItem("un",dt.token)
        this.rt.navigateByUrl("details")
      } 
    })
  }

  

  ngOnInit() {
  }

}
