import { Component, OnInit ,enableProdMode } from '@angular/core';
import {RestService} from "../rest.service";
import * as _ from 'lodash';

enableProdMode();

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  data;
  username=localStorage.getItem("username")

  constructor(public rs:RestService) { 
  }
  
  newdata////for company details
  companyname//// company name from grid
  contacts//// contact data 
  leads//// leads data
  ngOnInit() {
    this.rs.getuserdata(this.username).subscribe(dt=>{
      this.data=dt;
       this.newdata= this.data.recordsets[0]
       this.newdata= _.uniqBy(this.newdata,'CompanyName','linkedin');
      })
    }

    gridUserSelectionChange(gridUser,selection) {
      //let selectedData = gridUser.data.data[selection.index];
      const selectedData = selection.selectedRows[0].dataItem;
      this.companyname=selectedData.CompanyName
        this.fungetcompany();
        this.fungetleads();
    }

     fungetcompany(){
       this.rs.getcompany(this.companyname).subscribe(dt=>{
         this.contacts=dt
         this.contacts=this.contacts.recordsets[0]
        //  this.contacts = Math.max.apply(Math, this.contacts.map(o=>{ return o.cdate}))
         //  this.contacts=this.contacts.sort((a,b) => a.cdate.rendered.localeCompare(b.cdate.rendered));
         //this.contacts=this.contacts.sort((a,b)=>a.cdate.rendered > b.cdate.rendered)
         this.contacts= _.uniqBy(this.contacts, 'FullName','Designation','phone1','Ext','EmailId','cdate'); 
         //alert(JSON.stringify(this.contacts))
       })
     }

    fungetleads(){
      this.rs.getleads(this.companyname).subscribe(dt=>{
        this.leads=dt
        this.leads=this.leads.recordsets[0]
        this.leads= _.uniqBy(this.leads,'Position','Location','Status','linkedin','jobDescription','Ctype','TimeZone');
        //alert(JSON.stringify(this.leads))
        })
    }

  }
