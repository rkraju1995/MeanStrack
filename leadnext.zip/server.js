exp=require("express");
bp=require("body-parser");
app=exp()

session=require("express-session")
json=require("jsonwebtoken")
app.use(session({secret:"xy$%"}))

app.use(bp.json())
app.listen(1000)
sql = require("mssql");

detailsfile=require("./serverfiles/details")
app.use("/detailsref",detailsfile)

leadfile=require("./serverfiles/leads")
app.use("/leadsref",leadfile)

loginfile=require("./serverfiles/login")
app.use("/loginref",loginfile)