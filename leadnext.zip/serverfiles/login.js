exp=require("express")
router=exp.Router()

var sql = require("mssql");

router.post('/userlogin', function (req, res) {

    username=req.body.username
    password=req.body.password
    
    // console.log(username)
    // console.log(password)

    var request = new sql.Request();

    request.query("select * from users where userName='" + username + "',pwd='" + password + "'", function (err, result) {

        console.log(result)
        // if (result.length>=1){
        // str=json.sign({em:req.body.username},"*$#$%^&*")    
        // session=req.session
        // session.username=result[0].userName
        // session.token=str
        // console.log(session.username)
        // console.log(session.token)
        // res.send({tot:1,username:result[0].userName,token:str})
        // }
        // else{
        // res.send({tot:1})
        // }
    });



});

module.exports=router

