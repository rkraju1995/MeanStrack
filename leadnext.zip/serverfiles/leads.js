exp=require("express")
router=exp.Router()

var sql = require("mssql");

router.post('/getbyleads', function (req, res) {
    
    rbody=req.body.z

        var request = new sql.Request();
           
        request.query("select  CONCAT(contact_first_name , ' ', contact_last_name) as FullName,ID,CompanyName,Position,Location,Status,linkedin,jobDescription,Ctype from contact_address_leadsTli where contact_first_name is not null and contact_last_name is not null and CompanyName='" + rbody + "'" , function (err, result) {
           
            if (err) console.log(err)

            res.send(result);
  
        });
});


module.exports=router