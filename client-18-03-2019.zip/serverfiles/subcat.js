exp=require('express');
router=exp.Router()

router.get("/getsubcat",function(req,res){
con.tbl_subcat.find(function(err,result){
    res.send(result)
})
})

module.exports=router