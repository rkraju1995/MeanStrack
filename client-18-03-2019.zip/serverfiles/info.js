exp=require("express")
router=exp.Router()

router.post("/info",function(req,res){
    reqbody=req.body
    //console.log(reqbody)
    //console.log(req.body.uid)
    lid=1
con.tbl_order_info.find({},{_id:1}).sort({_id:-1}).limit(1,function(err,resu){
    if(resu.length==0)
    lid=1;
    else
    {
lid=resu[0]._id
lid++
    }
reqbody._id=lid

con.tbl_order_info.save(reqbody,function(err,result){
    res.send(result)
})
})
})


router.post("/details",function(req,res){
    rbody=req.body
    //console.log(rbody)
    lid=1
con.tbl_order_details.find({},{_id:1}).sort({_id:-1}).limit(1,function(err,resu){
    if(resu.length==0)
    lid=1;
    else
    {
lid=resu[0]._id
lid++
    }
rbody._id=lid

rbody.dispatch=0


con.tbl_order_details.save(rbody,function(err,result){
  res.send(result)
  //console.log(reqbody.uid)   
   })
  })
 })

 router.post("/getorders",(req,res)=>{
    sess=req.session
    utkon=req.body.usertoken
    // uid=uid.toString()
    //console.log(uid)
    console.log(sess.token)
    //console.log(utkon)
    if(sess.token==utkon){
        uid=sess.uid
        uid=uid.toString()
        console.log(uid)
    con.tbl_order_details.find({uid:uid},function(err,result){
        if(err)
        res.send(err)
        else
        res.send(result)
        console.log(result)
    })
    }
    else
    {
      res.send("Invalid Token")
    }
 })

 router.post("/removeprod",function(req,res){
    // console.log(req.body)
    uid=req.body.uid
    // console.log(uid)
    uid=parseInt(uid)
    con.tbl_cart.find({uid:uid},function(err,result){
        for(i=0;i<result.length;i++)
        {
            proid=result[i].pid;
            uqty=result[i].uqty
            con.tbl_product.find({_id:proid},function(err1,result1){
              //console.log(result1)
                 con.tbl_product.update({_id:result1[0]._id},{$set:{productqty:result1[0].productqty-uqty}},function(err2,result2){
                 con.tbl_cart.find({uid:uid},function(err3,result3){
                 con.tbl_cart.remove({uid:result3[0].uid},function(err4,result4){
                 console.log("removed")
                    })
                  })
              })
           })  
        }
    })
 })


module.exports=router