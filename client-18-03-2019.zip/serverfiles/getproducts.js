exp=require("express")
router=exp.Router()

///// To Get New Arrival Products /////
router.get("/get_pro_new_arrival",function(req,res){
    con.tbl_product.find({producttype:"1"}).sort({_id:-1}).limit(9,function(err,result){
    res.send(result)
    })
})

///// To Get Up Comming Products /////
router.get("/get_pro_up_comming",function(req,res){
    con.tbl_product.find({producttype:"2"}).sort({_id:-1}).limit(9,function(err,result){
    res.send(result)
    })
})

///// To Get Fast Selling Products /////
router.get("/get_pro_fast_selling",function(req,res){
    con.tbl_product.find({producttype:"3"}).sort({_id:-1}).limit(8,function(err,result){
    res.send(result)
    })
})

/////To Get One Product/////
router.post("/getproductdetais",function(req,res){
    tmp=parseInt(req.body.x)
    con.tbl_product.find({_id:tmp},function(err,result){
    res.send(result)
    })
})

/////To Get Product Based on subsubcat/////
router.post("/getallproductdetais",function(req,res){
    //console.log(req.body.y)
    tmp=(req.body.y)
    //console.log(tmp)
    mival=req.body.mi
    mxval=req.body.mx
   con.tbl_product.aggregate(
       [{$match:{subsubcatid:tmp,productprice:{$gte:mival,$lte:mxval}}}],function(e,r){
       res.send(r)
       console.log(r)
   })
    })
router.post("/search",function(req,res){
bdata=req.body
console.log(bdata.pn)
con.tbl_product.find({productname:{$regex:new RegExp(bdata.pn, "i")}},{productname:1},function(err,result){
res.send(result)
console.log(result)
})
})

module.exports=router