exp=require("express")
rs=require("request")
router=exp.Router()
router.post("/otpgen",function(req,res){
dt=new Date()
req.body.dtt=dt
con.tbl_coupen.save(req.body,function(){
  res.send("1")
})
})
router.post("/checkotp",function(req,re){
  console.log(req.body)
con.tbl_coupen.find(req.body,function(err,result){
  if(result.length==1)
  {
    d1=new Date(result[0].dtt)
    d2=new Date()
    res=d2-d1
    res=res/1000
    res=res/60
    if(res<2)
    re.send("1")
    else
    re.send("2")
    console.log(res)
  }
  else
  re.send("0")
})
})
router.post("/pay_now",function(req,res){
    bdata=req.body
    console.log(bdata.mobile,bdata.name)
    console.log(bdata)
var headers = { 'X-Api-Key': 'c330cd3507acf3592af026d934ca4d7e', 'X-Auth-Token': '1101238313b4ae53f9a6a9b142e4dfa1'}
var payload = {
  purpose: 'FIFA 16',
  amount: 10,
  phone: bdata.mobile,
  buyer_name: bdata.name,
  redirect_url: 'http://localhost:4200/#/paysuccess/',
  send_email: true,
  webhook: 'http://www.example.com/webhook/',
  send_sms: true,
  email: bdata.email,
  allow_repeated_payments: false}
rs.post('https://www.instamojo.com/api/1.1/payment-requests/', {form: payload,  headers: headers}, function(error, response, body){
    
	  str=JSON.parse(body)
	  console.log(body)
	  res.send({resp:str.payment_request.longurl})
})
})
module.exports=router