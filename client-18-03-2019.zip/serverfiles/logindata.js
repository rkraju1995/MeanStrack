exp=require("express")
router=exp.Router()


router.post("/cartdata",function(req,res){
   // console.log(req.body)
   prodata=req.body.dt
   arr=prodata.split("&&")
   newarr=[]
   for(i=0;i<arr.length;i++)
   {
      obj=JSON.parse(arr[i])
      obj.uid=parseInt(req.body.uid)
      newarr.push(obj)
   }

   con.tbl_cart.find({pid:newarr[0].pid,uid:newarr[0].uid},function(err,result){
    if(result.length>=1)
    {
      if(result[0].uqty<result[0].qty)
      con.tbl_cart.update({pid:result[0].pid,uid:result[0].uid},{$set:{uqty:result[0].uqty+1}},function(err1,result1){
        res.send(result1)
        })
      }
    else
    {
      con.tbl_cart.save(newarr,function(err2,resu){
        res.send(resu)
      })
    }
  })
})

router.post("/getcartdata",function(req,res){
 // console.log(req.body.uid)
    utkn=req.body.usertoken
    console.log(utkn)
    //console.log(utkn)
    session=req.session
    console.log(session.token)
    if(session.token==utkn){
      uid=session.uid
      uid=parseInt(uid)
     con.tbl_cart.find({uid:uid},function(err,result){
     res.send(result)
    })
    }
})

router.post("/inc_qty",function(req,res){
    rbody=req.body
    console.log(rbody.pid)
    con.tbl_cart.update({uid:rbody.uid,pid:rbody.pid},{$set:{uqty:rbody.uqty}},function(err,result){
        if(err)
        res.send(err)
        else
        res.send(result)
    })
})

router.post("/remove_prod",function(req,res){
    rbody=req.body
    console.log("uid"+rbody.uid)
    con.tbl_cart.remove({uid:rbody.uid,pid:rbody.pid},{$set:{uid:rbody.uid}},function(err,result){
        if(err)
        res.send(err)
        else
        res.send(result)
    })
})

module.exports=router