exp=require("express")
router=exp.Router()


router.post("/register",function(req,res){
    reqbody=req.body
    email=reqbody.email;
    lid=1
con.tbl_register.find({},{_id:1}).sort({_id:-1}).limit(1,function(err,resu){
    if(resu.length==0)
    lid=1;
    else
    {
lid=resu[0]._id
lid++
    }
console.log(lid)
reqbody._id=lid
rand=Math.random()
rand=rand*10000
rand=Math.round(rand)
randstr=email+rand
reqbody.emaillink=randstr
reqbody.active=0

con.tbl_register.createIndex({username:1},{unique:1},function(err1,result1){
    if(err1)
    res.send(err1)
    else
    con.tbl_register.save(reqbody,function(err,result){
    if(err)
    res.send(err)
    else
    {
        var obj=nodemailer.createTransport({
            service:"gmail",
                auth:{
                user:"ramakrishnach018@gmail.com",
                pass:"Kiran@53"
                }
            })
                str="Your Account is created click on activation link "
                linkstr="<a href=http://localhost:4200/#/activate;aclink="+randstr+">Click</a>"////from this url we are sending the aclink to activate component//////
                str+=linkstr
                obj.sendMail({
                from:"ramakrishnach018@gmail.com",
                to:email,
                subject:"Account Activation Link",
                html:str
                },function(err,result){
                if(err)
                    res.send(err)
                    else
                    res.send({x:"Registered"})
                })
    }
})  
})
})
})
router.post("/activate",function(req,res){
    rdata=req.body
    con.tbl_register.update(rdata,{$set:{active:1}},function(err,result){
    res.send({response:1})
    })
})
router.post("/login",function(req,res){
    con.tbl_register.find(req.body,function(err,result){////if the data matches it will give response 1 //////
        if(result.length>=1)
        {
            con.tbl_register.find({active:1,username:req.body.username},function(err,result2){//// if username is active or not ////
                if(result2.length==1)
                {
                    str=json.sign({em:req.body.username},"*$#$%^&*")////generating web token
                    ss=req.session//////to access the session into a variable
                    ss.un=result[0].username/////creating a session veriable
                    ss.uid=result[0]._id
                    ss.token=str/////adding generated token to the session variable
                    console.log(ss.un)
                    console.log(ss.uid)
                    console.log(ss.token)
                res.send({tot:1,act:1,uid:result[0]._id,un:result[0].username,em:result[0].email,tk:str})
                }
                else
                {res.send({tot:1,act:0})}
            })
        }
        else
        {
            res.send({tot:0,act:0})////// here it will tell usename is not matches response //////
        }
    })
})
    // router.post("/userdata",function(req,res){
    //     console.log("hiii")
    //     console.log(req.body.udata)
    //     uname=(req.body.udata)
    //     con.tbl_register.find({username:uname},function(err,result){
    //     res.send(result)
    //    })
    // })

    router.post("/userdata",function(req,res){
        sess=req.session
        utkn1=req.body.usertoken
        console.log(utkn1)
        console.log(sess.un)
        if(sess.token==utkn1){
        un=sess.un
        con.tbl_register.find({username:un},function(err,result){
        res.send(result)
       })
       }
       else
       {
           res.send("Invalid token")
       }
    })
    
    router.post("/updatedata",function(req,res){
        rdata=req.body
        var_session=req.session
        un=req.body.username
        utok=req.body.usertoken
        console.log(var_session.token)
        if(var_session.token==utok)
        {
            un=var_session.un
            //console.log(rdata)
                    con.tbl_register.find({username:un},function(err,result){
                      con.tbl_register.update({username:un},{$set:{username:rdata.username,email:rdata.email,mobile:rdata.mobile,address:rdata.address}},function(err1,result1){
                          res.send(result1)
                          //console.log(rdata)
                      })
                   })        }
        else
        {
            res.send("Invalid token")
        }
        
    })
    

module.exports=router