exp=require('express');
router=exp.Router()

router.get("/getsubsubcat",function(req,res){
con.tbl_subsubcat.find(function(err,result){
    res.send(result)
})
})

module.exports=router