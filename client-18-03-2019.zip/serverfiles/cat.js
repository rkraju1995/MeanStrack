exp=require("express")
router=exp.Router()

router.get("/getcat",function(req,res){
con.tbl_cat.find(function(err,result){
    res.send(result)
})
})

module.exports=router