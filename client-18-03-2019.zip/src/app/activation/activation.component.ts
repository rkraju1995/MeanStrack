import { Component, OnInit, Inject } from '@angular/core';
import {ActivatedRoute} from "@angular/router"
import {RestService} from "../rest.service"

@Component({
  selector: 'app-activation',
  templateUrl: './activation.component.html',
  styleUrls: ['./activation.component.css']
})
export class ActivationComponent implements OnInit {

   constructor(@Inject(ActivatedRoute) public ar,@Inject(RestService) public rs) { }
 
 urllink;
 tmp=0;
  
 ngOnInit() {
    this.ar.params.subscribe(dt=>{
      this.urllink=dt['aclink']
      this.rs.activateaccount(this.urllink).subscribe(dt=>{
        if(dt.response==1)
        this.tmp=1
      })
    })
  }

}
