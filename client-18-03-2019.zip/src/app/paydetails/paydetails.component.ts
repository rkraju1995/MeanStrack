import { Component, OnInit,Inject } from '@angular/core';
import {RestService} from "../rest.service";
import {ActivatedRoute} from "@angular/router";
import {Http} from "@angular/http"
declare var $:any
@Component({
  selector: 'app-paydetails',
  templateUrl: './paydetails.component.html',
  styleUrls: ['./paydetails.component.css']
})
export class PaydetailsComponent implements OnInit {
cart_details;
sum=0;
obj
user_data;
new_user_data;
un  

username;
password;
mobile;
email;
address;
pro_id

  constructor(@Inject(ActivatedRoute) public ar,@Inject(Http) public htp, public rs:RestService) {
    this.ar.params.subscribe(dt=>{
      this.pro_id=dt['pid']
      if(this.pro_id){
        this.rs.getprodetails(this.pro_id).subscribe(dt=>{
          this.cart_details=dt
          for(var k=0;k<this.cart_details.length;k++){
            this.cart_details.length
            this.sum=this.cart_details[k].productprice
          }
        })
       }else{
        var utkn=localStorage.getItem("tok")
        this.rs.getcartdata({usertoken:utkn}).subscribe(dt=>{
          this.cart_details=dt
          //alert(this.cart_details)
          for(var i=0;i<this.cart_details.length;i++){
            var tot=this.cart_details[i].price*this.cart_details[i].uqty
            this.cart_details.length
            this.sum+=tot
          } 
        })
       }
    })
   }

  ngOnInit() {
    var tkn =localStorage.getItem("tok")
    this.rs.getuserdata({usertoken:tkn}).subscribe(dt=>{
      this.user_data=dt
      for(var j=0;j<this.user_data.length;j++){
        this.username=this.user_data[j].username
        this.password=this.user_data[j].password
        this.mobile=this.user_data[j].mobile
        this.email=this.user_data[j].email
        this.address=this.user_data[j].address
      } 
     })
  }
 
  funsave(){
    
    let data={
      usertoken:localStorage.getItem("tok"),
      _id:this.user_data[0]._id,
      username:this.username,
      password:this.password,
      email:this.email,
      mobile:this.mobile,
      address:this.address,
    }
    this.rs.updatedata(data).subscribe(dt=>{
    })
    }
    fun_coup(){
      var rand=Math.random()
      rand=rand*10000
      rand=Math.round(rand)
      var obj={rn:rand,mb:this.mobile}
      this.htp.post("pay/otpgen",obj).subscribe(dt=>{
        if(dt._body=="1")
        {
          var str="http://www.onlinebulksmslogin.com/spanelv2/api.php?username=nalax&password=nalax@123&to="+this.mobile+"&from=TESTIN&message=Your OTP is "+rand
          this.htp.get(str).subscribe(dt=>{
            alert(dt)
          })
          alert("OTP Sent to your mobile")
        
        }
        else
        {
          alert("Failed")
        }
      })
    }
    txtotp
    fun_otp(){
      var obj={rn:parseInt(this.txtotp),mb:this.mobile}
      this.htp.post("pay/checkotp",obj).subscribe(dt=>{
        alert(dt._body)
      })
    }
    funget(){
      $.geolocate().done(x=>{
        this.address=x
      })
    }
fun_pay(){
this.funsave();
this.rs.payment({mobile:this.user_data[0].mobile,email:this.user_data[0].email,name:this.user_data[0].username,total:this.sum}).subscribe(dt=>{
  window.location.href=dt.resp
})
}
}
