import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LogserService {
  log_var=false;
  constructor() { }
}
