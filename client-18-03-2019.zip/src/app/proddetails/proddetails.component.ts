import { Component, OnInit ,Inject} from '@angular/core';
import {Router,ActivatedRoute} from "@angular/router";
import {RestService} from "../rest.service";
import {LogserService} from "../logser.service"
import {CartServiceService} from "../cart-service.service";
declare var $:any; 
@Component({
  selector: 'app-proddetails',
  templateUrl: './proddetails.component.html',
  styleUrls: ['./proddetails.component.css']
})
export class ProddetailsComponent implements OnInit {

  constructor(@Inject(LogserService) public ls,@Inject(CartServiceService) public cs,@Inject(Router) public rt,@Inject(ActivatedRoute) public ar,@Inject(RestService) public rs) {
    this.cs.currentmessage.subscribe(dt=>{
      this.cur_val=parseInt(dt)
    //  alert(this.cur_val)
    })
   }
   
pro_id;var_prodata;offers=[];big_img;desc;
cur_val;
objnew

/////
fun_pay_page(){
  if(localStorage.getItem("aut"))
  this.rt.navigate(['paydetails', {pid:this.pro_id}])
  else
  {
    this.ls.log_var=true
  }
}

fun_add_cart(){
  var obj={pid:this.var_prodata[0]._id,uqty:1,pname:this.var_prodata[0].productname,price:this.var_prodata[0].productprice,qty:this.var_prodata[0].productqty,image:this.var_prodata[0].pimages[0]}
 // alert(this.var_prodata[0]._id)
 if(localStorage.getItem("aut"))
 {
   this.rs.postlogdata({uid:localStorage.getItem("uid"),dt:JSON.stringify(obj)}).subscribe(dt=>{
    this.cur_val=this.cur_val+1
    this.cs.funnext(this.cur_val)
    this.rt.navigateByUrl("usercartpage")
   })
  
 }
 else{
  if(localStorage.getItem("prod"))
 {
  var tmp='"pid":'+this.var_prodata[0]._id+","////for cart component preparing string//////
  
  var play=0 /////if product is adding initially////
  var eval_prod=localStorage.getItem("prod")
  var arr=eval_prod.split("&&")
  var str=""
  for(var i=0;i<arr.length;i++)
  {
    if(arr[i].match(tmp))
    {
    var newobj=JSON.parse(arr[i])
    if(newobj.uqty<=newobj.qty)
    newobj.uqty++
    str+=JSON.stringify(newobj)
    play=1//////if product is already added then increase the quantity//////
    }
    else
    {
  str+=arr[i]
    }
  str+="&&"
  }
  //alert(play)
  if(play==0)
  {
  str+=JSON.stringify(obj)
  this.cur_val=this.cur_val+1
  //alert("abc"+this.cur_val)

  this.cs.funnext(this.cur_val)
  }
  else
  {
    str=str.substring(0,str.length-2)
  }
  localStorage.setItem("prod",str)
 }
  else{
   localStorage.setItem("prod",JSON.stringify(obj))
   this.cur_val=this.cur_val+1
   this.cs.funnext(this.cur_val)
  }
  this.rt.navigateByUrl("usercartpage")
}
  //this.rt.navigateByUrl("usercartpage")
}
  
  funget(){
    this.ar.params.subscribe(dt=>{
      this.pro_id=dt['pid']
    //  alert(this.pro_id)
      this.rs.getprodetails(this.pro_id).subscribe(dt=>{
        this.var_prodata=dt
        this.offers=this.var_prodata[0].productoffer.split("\n")
        this.desc=this.var_prodata[0].productdesc.split("\n")
        this.big_img=this.var_prodata[0].pimages[0]
       // alert(dt)
      })
    })
  }

  ngOnInit() {
    this.funget()
  }

}
