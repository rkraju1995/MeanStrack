import { Component, OnInit,Inject } from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import {RestService} from "../rest.service"
declare var  $:any
@Component({
  selector: 'app-menuproduct',
  templateUrl: './menuproduct.component.html',
  styleUrls: ['./menuproduct.component.css']
})
export class MenuproductComponent implements OnInit {
 allpro_id;
 var_allprodata;
 var_subsubcatid
 minval=0;
 maxval=0;
  constructor(@Inject(ActivatedRoute) public ar,@Inject(RestService) public rs) { }

  funget(){
    this.rs.postallprodetails(this.var_subsubcatid,this.minval,this.maxval).subscribe(dt=>{
    this.var_allprodata=dt
    })
  }

  ngOnInit() {
    $("document").ready(()=>{
      
      $("#div1").slider({
        range:true,
        min:100,
        max:100000,
        step:100,
        values:[1,1000],////// this is used for initial display range////////
        slide:(e,ui)=>{
          $("#divminmax").html("Min:"+ui.values[0]+" Max:"+ui.values[1])
          this.minval=parseInt(ui.values[0])
          this.maxval=parseInt(ui.values[1])
          //alert(this.minval)
        //  this.funget()
        }
      })
    })

    this.ar.params.subscribe(dt=>{
    this.var_subsubcatid=dt['pid']
   
    this.rs.postallprodetails(this.var_subsubcatid,0,100000).subscribe(dt=>{
    this.var_allprodata=dt
    
    
    })
      
    })
    
  }
}
