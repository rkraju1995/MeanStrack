import { Component, OnInit,Inject } from '@angular/core';
import {RestService} from "../rest.service"
import {CartServiceService} from "../cart-service.service"
import {Router} from "@angular/router"
import {LogserService} from "../logser.service"
import {HeaderComponent} from "../header/header.component"
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
   public hcom:HeaderComponent
  constructor(@Inject(LogserService) public ls, @Inject (Router) public rt,public rs:RestService,public cs:CartServiceService) {
  
  }
  
  ///// Global variables we declared //////
  var_prod;
  allprod=[]
  userqty=1;
  //prc
  //price
  str
  strold
  strnew
  ///////Function to Decrease the Products in cart page/////////
  fundown(pro_id,idnum,uid){
    var id="txt"+idnum
    var con=<HTMLInputElement>document.getElementById(id)
    this.userqty=parseInt(con.value)
    if(localStorage.getItem("aut")){
      if(this.userqty>1){
        this.allprod
        //alert(this.allprod)
      this.str='"pid":'+pro_id+',"uqty":'+this.userqty+"'uid':"+uid
      this.userqty--
      con.value=JSON.stringify(this.userqty)
      var prod_id=pro_id
      var uqty=this.userqty
      var uid=uid
      //alert(prod_id);
      //alert(uqty);
      this.rs.increaseqty({pid:prod_id,uqty:uqty,uid}).subscribe(dt=>{
        this.fungetcartproducts()
       })
      }
    }
    else{
    if(this.userqty>1)
    {
      this.var_prod=localStorage.getItem("prod")
      this.strold='"pid":'+pro_id+',"uqty":'+this.userqty
      this.userqty--
      this.strnew='"pid":'+pro_id+',"uqty":'+this.userqty 
     
      this.str=localStorage.getItem("prod")
      this.str=this.str.replace(this.strold,this.strnew)
      localStorage.setItem("prod",this.str)
      con.value=this.userqty.toString()
      this.fungetlocaldata()
     }
    }
  }
  
  ///////Function to increase the Products in cart page/////////
  funup(tot_qty,pro_id,idnum,uid){
    var id="txt"+idnum
    var con=<HTMLInputElement>document.getElementById(id)
    this.userqty=parseInt(con.value)
    
    if(localStorage.getItem("aut")){
      if(this.userqty<tot_qty){
        this.allprod
        //alert(this.allprod)
      this.str='"pid":'+pro_id+',"uqty":'+this.userqty+",'uid':"+uid
      this.userqty++
      con.value=JSON.stringify(this.userqty)
      var prod_id=pro_id
      var uqty=this.userqty
      var uid=uid
      //alert(prod_id);
      //alert(uqty);
      this.rs.increaseqty({pid:prod_id,uqty:uqty,uid:uid}).subscribe(dt=>{
        this.fungetcartproducts()
      })
      }
    }
    else{
    if(this.userqty<tot_qty)
    {
      var strold='"pid":'+pro_id+',"uqty":'+this.userqty
      this.userqty++
      var strnew='"pid":'+pro_id+',"uqty":'+this.userqty
      // alert(strold)
      // alert(strnew)
      this.str=localStorage.getItem("prod")
      this.str=this.str.replace(strold,strnew)
      localStorage.setItem("prod",this.str)
      con.value=this.userqty.toString()
    this.fungetlocaldata() 
    }
   }
  }

  x;
  fun_payment_page(){
    if(localStorage.getItem("aut"))
    this.rt.navigateByUrl("paydetails")
    else
    {
      this.ls.log_var=true
    }
  }
  ///////Function to delete the products from the cart//////////
  fundel(var_pid,uid){
    //alert(uid)
    this.tmp1=1
    if(localStorage.getItem("aut")){
     this.rs.deletecartpro({pid:var_pid,uid:uid}).subscribe(dt=>{
      this.cs.currentmessage.subscribe(dt=>{
        this.x=parseInt(dt)
       this.x=this.x-1
      
      })
      this.cs.funnext(this.x)
     })
    }
    else{
    var str=""
    this.var_prod=localStorage.getItem("prod")
    var arr=this.var_prod.split("&&")
    this.allprod=[];
    this.cs.currentmessage.subscribe(dt=>{
       this.x=parseInt(dt)
      this.x=this.x-1
    })
    this.cs.funnext(this.x)
    for(var i=0;i<arr.length;i++)
    {
      var obj=JSON.parse(arr[i])
      if(obj.pid!=var_pid)
      {
      this.allprod.push(obj)
      str+=JSON.stringify(obj)
      str+="&&"
      }
    }
    this.tmp1=0
    alert(str.length)
    str=str.substring(0,str.length-2)
    alert(str)
    localStorage.setItem("prod",str)
    if(localStorage.getItem(str)=== null)
    this.emptytmp=0
    this.fungetlocaldata()
  }
  this.fungetcartproducts()
}

var_grand_tot=0
tmp1=1
emptytmp=1
fungetcartproducts(){
  this.allprod=[]
  var tkn=localStorage.getItem("tok")
this.rs.getcartdata({usertoken:tkn}).subscribe(dt=>{
  this.tmp1=0
  this.allprod=dt
  if(dt.length==0)
  this.emptytmp=0
  this.cs.currentmessage.subscribe(dt=>{
    this.x=parseInt(dt)
    this.cs.funnext(this.x)
 })
for(var j=0;j<this.allprod.length;j++)////for grand total we are running the loop/////
{
var tot=this.allprod[j].uqty*this.allprod[j].price
// alert(tot)
this.allprod[j].protot=tot///////here we are declaring the product protot to allpro//////
this.var_grand_tot+=tot
}
})

  }  
  ///////Function to get the products////////
  ngOnInit() {
    if(localStorage.getItem("aut"))
    {
    this.fungetcartproducts()
    this.cs.currentmessage.subscribe(dt=>{
      this.x=parseInt(dt)
      this.x=this.x
      this.cs.funnext(this.x)
   })
  }
   else{
    this.fungetlocaldata()
  }
 }
 fungetlocaldata(){
  this.var_prod=localStorage.getItem("prod")
  var arr=this.var_prod.split("&&")
  this.allprod=[]

  this.var_grand_tot=0
  for(var i=0;i<arr.length;i++)
  {
    var obj=JSON.parse(arr[i])
    var tot=obj.uqty*obj.price
obj.protot=tot///////here we are declaring the product protot to allpro//////
this.tmp1=0
this.allprod.push(obj)
if(this.allprod.length==0)
this.emptytmp=0
this.var_grand_tot+=tot
  }
 }
}


