import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HashLocationStrategy,LocationStrategy} from "@angular/common"
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { ContentComponent } from './content/content.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import {RouterModule} from '@angular/router';
import {FormsModule,ReactiveFormsModule} from "@angular/forms";
import {HttpClientModule} from '@angular/common/http';
import { BannerComponent } from './banner/banner.component';
import {ProddetailsComponent}  from "./proddetails/proddetails.component";
import { MenuproductComponent } from './menuproduct/menuproduct.component';
import { ActivationComponent } from './activation/activation.component';
import { CartComponent } from './cart/cart.component';
import {ImageZoomModule} from "angular2-image-zoom"
import { PaydetailsComponent } from './paydetails/paydetails.component';
import { PaysuccessComponent } from './paysuccess/paysuccess.component';
import { ShoworderComponent } from './showorder/showorder.component';
import { ProfileComponent } from './profile/profile.component'
import {HttpModule} from "@angular/http"
var rout=[
  {path:"paydetails",component:PaydetailsComponent},
  {path:'header',component:HeaderComponent },
  {path:'menu',component:MenuComponent},
  {path:'content',component:ContentComponent},
  {path:'',component:ContentComponent},
  {path:'footer',component:FooterComponent},
  {path:'prodet',component:ProddetailsComponent},
  {path:'allprod',component:MenuproductComponent},
  {path:'activate',component:ActivationComponent},
  {path:'usercartpage',component:CartComponent},
  {path:'paysuccess',component:PaysuccessComponent},
  {path:'profile',component:ProfileComponent},
  {path:'orders',component:ShoworderComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    ContentComponent,
    FooterComponent,
    HeaderComponent,
    BannerComponent,
    ProddetailsComponent,
    MenuproductComponent,
    ActivationComponent,
    CartComponent,
    PaydetailsComponent,
    PaysuccessComponent,
    ShoworderComponent,
    ProfileComponent
  ],
  imports: [
    HttpModule,BrowserModule,HttpClientModule,RouterModule.forRoot(rout),FormsModule,ImageZoomModule,
    ReactiveFormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl:'never'})
  ],
  providers: [{useClass:HashLocationStrategy,provide:LocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule { }
