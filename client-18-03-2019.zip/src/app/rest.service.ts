import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RestService {

  constructor(public ht:HttpClient) { }
  public dt(res:Response){
    return res;
  }
  
  ////// Get Cat Data ///////
  restgetcatser():Observable<any>{
     return(this.ht.get("catref/getcat").pipe(map(this.dt)))
  }

  ////// Get Subcat Data ///////
  restgetsubcatser():Observable<any>{
    return(this.ht.get("subcatref/getsubcat").pipe(map(this.dt)))
  }
  
  ////// Get Subsubcat Data ///////
  restgetsubsubcatser():Observable<any>{
    return(this.ht.get("subsubcatref/getsubsubcat").pipe(map(this.dt)))
  }

  /////Ser for New Arrival ////////
  restgetnewarrival():Observable<any>{
    return (this.ht.get("productref/get_pro_new_arrival").pipe(map(this.dt)))
  }

   /////Ser for Up Comming ////////
   restgetupcomming():Observable<any>{
    return (this.ht.get("productref/get_pro_up_comming").pipe(map(this.dt)))
  }

   /////Ser for fast selling ////////
   restgetfasesell():Observable<any>{
    return (this.ht.get("productref/get_pro_fast_selling").pipe(map(this.dt)))
  }

   ////To get one product complete details////////
   getprodetails(pid):Observable<any>{
  return(this.ht.post("productref/getproductdetais",{x:pid}).pipe(map(this.dt)))
  }

  /////To get product based on subsubcat complete details///////
  postallprodetails(pid,min,max):Observable<any>{
    return(this.ht.post("productref/getallproductdetais",{y:pid,mi:min,mx:max}).pipe(map(this.dt)))
  }

  ////To activate account///////
  activateaccount(var_link):Observable<any>{
    return(this.ht.post("regref/activate",{emaillink:var_link}).pipe(map(this.dt)))
  }
  
  //// To login //////
  loginaccount(var_object):Observable<any>{
    return(this.ht.post("regref/login",var_object).pipe(map(this.dt)))
  }

  /////to send the cart products after login/////
  postlogdata(logdata):Observable<any>{
    return(this.ht.post("logref/cartdata",logdata).pipe(map(this.dt)))
  }

  ////Get cart data based on uid is///////
  getcartdata(data):Observable<any>{
    return(this.ht.post("logref/getcartdata",data).pipe(map(this.dt)))
  }
  
  ///////To increase and decrease the product///////
  increaseqty(obj):Observable<any>{
    return(this.ht.post("logref/inc_qty",obj).pipe(map(this.dt)))
  }
  
  //////After purchase deleting the cart product///////
  deletecartpro(del_data):Observable<any>{
    return(this.ht.post("logref/remove_prod",del_data).pipe(map(this.dt)))
  }
  
  /////To access the payment instamojo////////
  payment(dt):Observable<any>{
    return(this.ht.post("pay/pay_now",dt).pipe(map(this.dt)))
  }
  
  ///////To get the data of perticuler user based on the uname//////
  getuserdata(udata):Observable<any>{
    return(this.ht.post("regref/userdata",udata).pipe(map(this.dt)))
  }
  
  //////To store the data of the user after purchase//////
  datatoinfo(data):Observable<any>{
     return(this.ht.post("inforef/info",data).pipe(map(this.dt)))
  }
  
  ///////To save the data of the orders after purchase//////
  datatodetails(dt):Observable<any>{
    return(this.ht.post("inforef/details",dt).pipe(map(this.dt)))
 }
  
  ////////To get the user purchased orders////////
  getorderdata(dt):Observable<any>{
  return(this.ht.post("inforef/getorders",dt).pipe(map(this.dt)))
 }

 //////To update the register user data///////
  updatedata(obj):Observable<any>{
  return(this.ht.post("regref/updatedata",obj).pipe(map(this.dt)))
 }

/////To decrease the product in the product table after purchase//////
productremove(data):Observable<any>{
  return(this.ht.post("inforef/removeprod",data).pipe(map(this.dt)))
 }
 
}
