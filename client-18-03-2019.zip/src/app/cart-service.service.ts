import { Injectable } from '@angular/core';
import {BehaviorSubject} from "rxjs"
@Injectable({
  providedIn: 'root'
})
export class CartServiceService {
bsobj;currentmessage;
  constructor() { 
    this.bsobj=new BehaviorSubject("0")
    this.currentmessage=this.bsobj.asObservable()
  }
  funnext(arg1)
  {
    this.bsobj.next(arg1)
  }
}
