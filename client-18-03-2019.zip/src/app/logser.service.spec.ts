import { TestBed } from '@angular/core/testing';

import { LogserService } from './logser.service';

describe('LogserService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LogserService = TestBed.get(LogserService);
    expect(service).toBeTruthy();
  });
});
