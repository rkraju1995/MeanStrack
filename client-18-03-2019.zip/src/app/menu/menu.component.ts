import { Component, OnInit,Inject } from '@angular/core';
import {RestService} from "../rest.service"

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  constructor(@Inject(RestService) private rs) { }

  ngOnInit() {
    this.getcat();
    this.getsubcat();
    this.getsubsubcat();
  }
  catdata;subcatdata;subsubcatdata
  
  getcat(){
    this.rs.restgetcatser().subscribe(dt=>{
      this.catdata=(dt)
    })
  }
  getsubcat(){
    this.rs.restgetsubcatser().subscribe(dt=>{
      this.subcatdata=(dt)
    })
  }
  getsubsubcat(){
    this.rs.restgetsubsubcatser().subscribe(dt=>{
      this.subsubcatdata=(dt)
    })
  }
}
