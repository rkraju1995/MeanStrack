import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  udata;
  constructor(public rs:RestService) {
    var tkn=localStorage.getItem("tok")
    this.rs.getuserdata({usertoken:tkn}).subscribe(dt=>{
      this.udata=dt
    })
   }


  
  ngOnInit() {
  }
  

fun5(){
let data={
  usertoken:localStorage.getItem("tok"),
  _id:this.udata[0]._id,
  username:this.udata[0].username,
  password:this.udata[0].password,
  email:this.udata[0].email,
  mobile:this.udata[0].mobile,
  address:this.udata[0].address,
}
this.rs.updatedata(data).subscribe(dt=>{
  alert("Your Profile Is Updated")
})

}

}

