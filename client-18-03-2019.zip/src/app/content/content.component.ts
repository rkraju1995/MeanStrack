import { Component, OnInit,Inject } from '@angular/core';
import {RestService} from './../rest.service'
import $ from "jquery"

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {

  constructor(@Inject(RestService) public rs) { }

  ngOnInit() {
    this.fastselling();
    this.newarrival();
    this.upcommming();
  }
  
  var_fastsell_data;      //////Fast Selling Data/////
  var_newarrival_data;    //////New Arrival Data/////
  var_upcomming_data;     /////Up Comming Data//////
  lpos=0;                 //////To Move Left //////

  funnext(){
    $("#btnnext").hide()
    $('#btnpre').show()
    this.lpos-=400
    $("#innerdiv").animate({"left":this.lpos},500)
  }

  funpre(){
    $("#btnnext").show()
      $("#btnpre").hide()
    this.lpos=0
    $("#innerdiv").animate({"left":this.lpos},500)
  }

  funnext1(){
    $("#btnnext1").hide()
    $('#btnpre1').show()
    this.lpos-=400
    $("#innerdiv1").animate({"left":this.lpos},500)
  }

  funpre1(){
    $("#btnnext1").show()
      $("#btnpre1").hide()
    this.lpos=0
    $("#innerdiv1").animate({"left":this.lpos},500)
  }

  funnext2(){
    $("#btnnext2").hide()
    $('#btnpre2').show()
    this.lpos-=400
    $("#innerdiv2").animate({"left":this.lpos},500)
  }

  funpre2(){
    $("#btnnext2").show()
      $("#btnpre2").hide()
    this.lpos=0
    $("#innerdiv2").animate({"left":this.lpos},500)
  }

  fastselling(){
    this.rs.restgetfasesell().subscribe(dt=>{
      this.var_fastsell_data=dt
    })
    }
  
  newarrival(){
    this.rs.restgetnewarrival().subscribe(dt=>{
       this.var_newarrival_data=dt
    })
  }

  upcommming(){
    this.rs.restgetupcomming().subscribe(dt=>{
      this.var_upcomming_data=dt
    })
  }
}
