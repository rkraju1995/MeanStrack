import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';

@Component({
  selector: 'app-showorder',
  templateUrl: './showorder.component.html',
  styleUrls: ['./showorder.component.css']
})
export class ShoworderComponent implements OnInit {

  order_data;
  constructor(public rs:RestService) { 
    var utkn=localStorage.getItem("tok")
    this.rs.getorderdata({usertoken:utkn}).subscribe(dt=>{
      this.order_data=dt
    })
  }

  ngOnInit() {
  }

}
