import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-paysuccess',
  templateUrl: './paysuccess.component.html',
  styleUrls: ['./paysuccess.component.css']
})
export class PaysuccessComponent implements OnInit {
  str;
  paystatus;
  tmp;
  txnnum;
  un;
  udata;
  cart_details;
  pid
  uqty
  sum = 0;
  constructor(public rs: RestService, public rt: Router) {
    this.str = window.document.URL
    var arr = this.str.split("?")
    var newarr = arr[1].split("&")

    this.paystatus = newarr[1].split("=")
    if (this.paystatus[1] == "Failed") {
      this.tmp = 0
    }
    else {
      this.tmp = 1
      var str = newarr[2].split("=")
      this.txnnum = (str[1])
    }
    this.fungetcartdata();
  }

  fungetcartdata(){
    var utkn=localStorage.getItem("tok")
    this.rs.getcartdata({usertoken:utkn}).subscribe(dt=>{
      this.cart_details=dt
      for(var i=0;i<this.cart_details.length;i++){
        var tot=this.cart_details[i].price*this.cart_details[i].uqty
        this.pid=this.cart_details[i].pid
        this.uqty=this.cart_details[i].uqty
        this.sum+=tot
      } 
    })
  }


  fungetudata() {
   var tkn=localStorage.getItem("tok")
    this.rs.getuserdata({usertoken:tkn}).subscribe(dt => {
      this.udata = dt
      //alert(this.udata[0].email)
    })

  }

  funinfo() {
    var uid = localStorage.getItem("uid")
    this.rs.datatoinfo({ uid: uid, order_id: this.txnnum, email: this.udata[0].email, mobile: this.udata[0].mobile, total_amt: this.sum, date: new Date(), address: this.udata[0].address }).subscribe(dt => {
    })
    this.rs.datatodetails({ uid: uid, order_id: this.txnnum, total_amt: this.sum, date: new Date(), product: this.cart_details }).subscribe(dt => {
    })
    this.rs.productremove({uid:uid}).subscribe(dt=>{
    })
    this.fungetcartdata();
    this.rt.navigateByUrl("")
  }

  funfailed() {
    this.rt.navigateByUrl("usercartpage")
  }

  ngOnInit() {
    this.fungetudata()
  }

}
