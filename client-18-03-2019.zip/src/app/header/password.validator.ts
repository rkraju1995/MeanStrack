import { FormGroup,AbstractControl } from '@angular/forms';

export function PasswordValidator(control:AbstractControl) {
if(control && (control.value !==null || control.value !== undefined)){
    const retype_password_value = control.value;

    const passControl= control.root.get('password');
    if(passControl){
        const passValue = passControl.value;
        if(passValue !== retype_password_value){
            return{
                isError: true
            };
        }
    }
}
return null;
}