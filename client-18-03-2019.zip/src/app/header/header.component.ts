import { Component, OnInit,Inject } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {RestService} from "../rest.service";
import { FormBuilder, FormGroup , Validators } from '@angular/forms';
import { PasswordValidator } from '../header/password.validator';
import {CartServiceService} from "../cart-service.service"
import {Http} from "@angular/http"
import {LogserService} from "../logser.service";
import {Router} from "@angular/router";
declare var $:any
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html', 
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  rForm: FormGroup;
  post:any; 
  name:string='';
  email:string=''
  password:string='';
  retype_password: string='';
  mobile: string='';
  address: string='';
  search_data;
  cartvalue=0;
  totpro;txtsearch;var_search_tmp=0
  
  funsearch(){
    this.var_search_tmp=1
   var obj={pn:this.txtsearch}
   this.ht2.post("productref/search",obj).subscribe(dt=>{
     this.search_data=JSON.parse(dt._body)
    // alert(this.search_data.length)
     if(this.txtsearch.length==0)
     {
     this.var_search_tmp=0
     }
   })
  }

  fun_show(){
    this.rt.navigateByUrl("orders")
    this.tmpprofile=0
   }
 
   fun_profile(){
     this.rt.navigateByUrl("profile")
     this.tmpprofile=0
   }

  constructor(public rt:Router,@Inject(LogserService) public ls,@Inject(CartServiceService) public cs, public ht:HttpClient,private fb: FormBuilder,public rs:RestService,@Inject(Http) public ht2) {
    this.getcartdata();
    this.rForm = fb.group({
      'name':[null, Validators.required],
      'address':[null, Validators.required],
      'mobile': [null, [Validators.required, Validators.maxLength]],
      'email':[null,   [Validators.required, Validators.email]],
     'password': [null, Validators.required],
     'retype_password': [null,PasswordValidator ]
    });
   }

   getcartdata(){
    if(localStorage.getItem("aut")){
      var tkn=localStorage.getItem("tok")
      this.rs.getcartdata({usertoken:tkn}).subscribe(dt=>{
       this.totpro=dt
       this.totpro=this.totpro.length
       this.cs.funnext(this.totpro.toString())
       this.cs.currentmessage.subscribe(dt=>{
        this.cartvalue=dt
      })
      })
    }
    else
    {
    if(localStorage.getItem("prod"))
    {
      this.totpro=localStorage.getItem("prod").split("&&").length
      this.cs.funnext(this.totpro.toString())
    }
    this.cs.currentmessage.subscribe(dt=>{
      this.cartvalue=dt 
    })
  }
   }

  ngOnInit() {
    if(localStorage.getItem("aut"))////// At the time of pageloding and aut is 1 it will display the username on the header/////
    {
      this.tmplogin=0
      this.var_loguname=localStorage.getItem("un")
      this.var_logemail=localStorage.getItem("email")
    }
  }
 
  var_username;var_loguname;var_logemail
  var_password
  var_email;
  var_mobile;
  var_address;
  var_uname;
  var_pwd
  regtmp=true
  tmplogin=1
  tmpprofile=0
  log_data/////Variable to passthe valu to the database//////
  logprod=[]////to store the data into array//////
  
  ////// Function register /////
  fun_register(){
    var obj={ 
       username:this.var_username,
       password:this.var_password,
       email:this.var_email,
       mobile:this.var_mobile,
       address:this.var_address
    }
    this.ht.post("regref/register",obj).subscribe(dt=>{
    if(dt=="Registered")
    {
      alert("Registration Success click on activation link")
      location.href="http://localhost:4200"
    }
    })
  }
  
  ////// function Login /////// 
  funlogin(){
  var obj={username:this.var_uname,password:this.var_pwd}
  this.rs.loginaccount(obj).subscribe(dt=>{
  if(dt.tot==0)
  alert("Invalid username/password")
  else if(dt.tot==1 && dt.act==0)
  alert("Your account is not activated")
  else
  {
    this.ls.log_var=false    //console.log(dt)
    localStorage.setItem("uid",dt.uid)
    localStorage.setItem("un",dt.un)
    localStorage.setItem("email",dt.em)
    localStorage.setItem("aut","1") 
    localStorage.setItem("tok",dt.tk)
    this.tmplogin=0
    this.var_loguname=localStorage.getItem("un")////// declaring to an variable /////
    this.var_logemail=localStorage.getItem("email")
    this.getcartdata();
  var str=localStorage.getItem("prod")
  if(localStorage.getItem("prod"))
  { 
  this.rs.postlogdata({uid:dt.uid,dt:str}).subscribe(dt=>{
  })  
  localStorage.removeItem("prod")
  }
  } 
    
})
}

////// Function Logout ///////
funlogout(){
  localStorage.clear(),
  location.href="http://localhost:4200"
}
  
}


