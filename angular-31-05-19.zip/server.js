exp=require("express");
bp=require("body-parser");
app=exp()

session=require("express-session")
json=require("jsonwebtoken")
app.use(session({secret:"xy$%"}))

app.use(bp.json())
app.listen(1000)

detailsfile=require("./serverfiles/details")
app.use("/detailsref",detailsfile)

leadfile=require("./serverfiles/leads")
app.use("/leadsref",leadfile)

loginfile=require("./serverfiles/login")
app.use("/loginref",loginfile)

Statusfile=require("./serverfiles/status")
app.use("/statusref",Statusfile)

Sainexfile=require("./serverfiles/sainex")
app.use("/sainexref",Sainexfile)


 app.get("/arr",function(req,res){

     var numbers=[3,6,6,5,2,1,0,4,4]

     numbers.unshift(0)/////To add element at the First position  
     numbers.push(0)/////To add element at the Last position

    ///// To Duplicates Remove
    var a = [];
    for ( i = 0; i < numbers.length; i++ ) {///// For Duplicates Remove
        var current = numbers[i];
        if (a.indexOf(current) < 0) 
        a.push(current);
    }
    numbers.length = 0;
    for ( i = 0; i < a.length; i++ ) {
        numbers.push( a[i] );
    }
    
    //////To make ascending or descending order
    for (var i = 0; i < numbers.length ; i++) {
        for (var j = i ; j < numbers.length ; j++) {
            if (numbers[i] > numbers[j]) {
                tempVar = numbers[i];
                numbers[i] = numbers[j];
                numbers[j] = tempVar;
            }
        }
    }
    //numbers.push(tempVar)
    //numbers=numbers.slice(0,-1)
    //console.log(numbers)
    res.send(numbers)
})