exp=require("express")
router=exp.Router()

// var sql = require("mssql")

// var config = {
//     user: 'dev', 
//     password: '123456',
//     server: 'TLIHYDDT128\\SQLEXPRESS', 
//     database: 'LeadNext' ,
//     port : 1433
// };


router.post("/updatesainex",function(req,res){

    firstname=req.body.firstname
    lastname=req.body.lastname
    companyname=req.body.companyname
    bdmname=req.body.bdmname
    designation=req.body.designation
    emailId=req.body.emailId
    phone=req.body.phone
    ext=req.body.ext
    cdate=req.body.cdate
    notes=req.body.notes
    marketing=req.body.marketing

    console.log(firstname,lastname,companyname,bdmname,designation,
                emailId,phone,ext,cdate,notes,marketing)

})    

module.exports=router