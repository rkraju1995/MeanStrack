exp=require("express")
router=exp.Router()

var sql = require("mssql");

var config = {
    user: 'dev', 
    password: '123456',
    server: 'TLIHYDDT128\\SQLEXPRESS', 
    database: 'LeadNext' ,
    port : 1433
};

router.post('/getbyleads', function (req, res) {
    
    rbody=req.body
    companyname=rbody.companyname
    bdmname=rbody.bdmname
    // console.log(companyname)
    // console.log(bdmname)
    sql.close()
       
    sql.connect(config, function (err) {
    
        if (err) console.log(err);
     
        var request = new sql.Request();
           
        request.query("select  CONCAT(contact_first_name ,' ', contact_last_name) as FullName,ID,CompanyName,BDMName,Position,Location,Status,linkedin,jobDescription,Ctype,(select st_state_timezone from LNTBL_STATES where st_state_code=client_state) as time_zone from contact_address_leadsTli where contact_first_name is not null and contact_last_name is not null and CompanyName='" + companyname + "'and bdmname ='" + bdmname + "' and (Status<>'DNC' or Status is null)" , function (err, result) {
           
            if (err) console.log(err)

            res.send(result);
  
        });

    });  
});


module.exports=router