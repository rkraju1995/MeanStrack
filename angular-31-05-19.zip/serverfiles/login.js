exp=require("express")
router=exp.Router()

var sql = require("mssql");


var config = {
    user: 'dev', 
    password: '123456',
    server: 'TLIHYDDT128\\SQLEXPRESS', 
    database: 'LeadNext' ,
    port : 1433
};

router.post('/userlogin', function (req, res) {

    username=req.body.username
    password=req.body.password
    
    //console.log(username)
    sql.close()
    // console.log(password)
    sql.connect(config, function (err) {
    
        if (err) console.log(err);


    var request = new sql.Request();

    request.query("select * from users where userName='"+ username +"' and pwd='"+ password +"'", function (err, result) {
        
        if (err)
        console.log(err)
        else
        //console.log(result.recordset[0])
        if (result.recordset[0]==undefined){
        res.send({tot:0})
        }
        else if(result){
            ///console.log("Haiii")
            str=json.sign({em:req.body.username},"*$#$%^&*")    
            session=req.session
            session.username=result.recordset[0].userName
            session.token=str
            //console.log(session.username)
            //console.log(session.token)
            res.send({tot:1,username:result.recordset[0].userName,token:str})
        }
    });

  });

});


module.exports=router

