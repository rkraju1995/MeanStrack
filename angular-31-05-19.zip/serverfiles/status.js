exp=require("express")
router=exp.Router()

var sql = require("mssql")

var config = {
    user: 'dev', 
    password: '123456',
    server: 'TLIHYDDT128\\SQLEXPRESS', 
    database: 'LeadNext' ,
    port : 1433
};

router.post("/updatestatus",function(req,res){
    
    firstname=req.body.firstname
    lastname=req.body.lastname
    status=req.body.status
    id=req.body.id
    bdmname=req.body.bdmname
    companyname=req.body.companyname
    
    // console.log(id)
    // console.log(status)
    // console.log(bdmname)
    // console.log(companyname)

    sql.close()
    

    sql.connect(config, function (err) {
    
        if (err) console.log(err);

        var request = new sql.Request();

        if(status==undefined)
         status="NULL"
         
    request.query("update [dbo].[contact_address_leadsTli] set status='" + status + "' where contact_first_name='"+ firstname +"' and contact_last_name='"+ lastname +"' and CompanyName='"+ companyname +"' and BDMName='"+ bdmname +"'", function (err, result) {
        if(err)
        res.send(err)
        else
        res.send(result)
      })

    })

 })

 router.post("/leadstatusupdate",function(req1,res1){
    
    firstname=req1.body.firstname
    lastname=req1.body.lastname
    status=req1.body.status
    id=req1.body.id
    bdmname=req1.body.bdmname
    companyname=req1.body.companyname
    
    // console.log(id)
    // console.log(status)
    // console.log(bdmname)
    // console.log(companyname)

    sql.close()
    

    sql.connect(config, function (err) {
    
        if (err) console.log(err);

        var request = new sql.Request();

        if(status==undefined){
          status="NULL"
        }
         else{
    request.query("update [dbo].[contact_address_leadsTli] set status='" + status + "' where contact_first_name='"+ firstname +"' and contact_last_name='"+ lastname +"' and CompanyName='"+ companyname +"' and BDMName='"+ bdmname +"'", function (err1, result1) {
        if(err)
        res1.send(err1)
        else
        res1.send(result1)
      })
    }

    })

 })

module.exports=router