import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import {map} from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class RestService {

  constructor(public ht:HttpClient) { }

  public dt(res:Response){
    return res
  }

   UserLoginService(userData):Observable<any>{
    //alert(JSON.stringify(userData))
    return(this.ht.post("loginref/userlogin",userData).pipe(map(this.dt)))
  }

  getuserdata(uname):Observable<any>{
    //alert(uname)
    return(this.ht.post("detailsref/getdata",{x:uname}).pipe(map(this.dt)))
  }

  getcompany(cmpname):Observable<any>{
    //alert(cmpname)
    return(this.ht.post("detailsref/getbycompany",cmpname).pipe(map(this.dt)))
  }

  getleads(name):Observable<any>{
    //alert(name)
    return(this.ht.post("leadsref/getbyleads",name).pipe(map(this.dt)))
  }

  changeStatusDnc(status):Observable<any>{
    return(this.ht.post("statusref/updatestatus",status).pipe(map(this.dt)))
  }

  changeStatusleads(status):Observable<any>{
    return(this.ht.post("statusref/leadstatusupdate",status).pipe(map(this.dt)))
  }

  sendToSainex(data):Observable<any>{
    // alert(JSON.stringify(data))
    return(this.ht.post("sainexref/updatesainex",data).pipe(map(this.dt)))
  }
  
}
