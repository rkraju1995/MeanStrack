import { Component, OnInit ,enableProdMode } from '@angular/core';
import {RestService} from "../rest.service";
import {Router} from "@angular/router"
import * as _ from 'lodash';

enableProdMode();

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  data;
  username=localStorage.getItem("username")

  constructor(public rs:RestService,public rt:Router) { 
  }
  
  newdata////for company details
  companyname//// company name from grid
  contacts//// contact data 
  leads//// leads data
  bdmname
  contact;
  dropdownstatus;
  contactid
  contactfirstname
  contactlastname
  contactstatus
  contactbdmname
  contactcompanyname

  //////For sainex global values
  textbox1;
  textbox2;
  lastname;
  firstname;
  sainexcompanyname;
  sainexbdmname
  designation
  emailId
  phone
  ext
  cdate

  public dropDown: Array<any> = [
      {value:'DNC'}
    //{ text: "DNC", value: "DNC" }
  ];

  public leadsdropDown: Array<any> = [
    {value:'No Goes'},{value:'CallBack'},{value:'Goes'},{value:'STFG'}
  ];
  
  private _opened: boolean = false;

  ngOnInit() {
    this.rs.getuserdata(this.username).subscribe(dt=>{
      this.data=dt;
       this.newdata= this.data.recordsets[0]
       this.newdata= _.uniqBy(this.newdata,'CompanyName','linkedin');
      })
    }

    gridUserSelectionChange(gridUser,selection) {
      //let selectedData = gridUser.data.data[selection.index];
      const selectedData = selection.selectedRows[0].dataItem;
      // alert(JSON.stringify(selectedData))
      this.companyname=selectedData.CompanyName
      this.bdmname=selectedData.BDMName
       //alert(JSON.stringify(this.companyname))
        this.fungetcompany();
        this.fungetleads();
    }

    contactUserSelectionChange(selection){  
      const selectedData = selection.selectedRows[0].dataItem;
      //this.contact =selectedData.FullName
      alert(JSON.stringify(selectedData))
      //alert(JSON.stringify(this.dropDownData))
    }

    leadsUserSelectionChange(selection){
      const selectedData = selection.selectedRows[0].dataItem;
      alert(JSON.stringify(selectedData))
    }
    
    sidebarData
    name
    onEdit(data){
      this._opened = !this._opened;
      this.sidebarData=data;
      this.name=this.sidebarData.FullName
      //alert(JSON.stringify(this.sidebarData))
    }
   
    sendToSainex(sainexdata){
      this.lastname=sainexdata.FullName
      this.sainexcompanyname=sainexdata.CompanyName
      this.sainexbdmname=sainexdata.BDMName
      this.designation=sainexdata.Designation
      this.emailId=sainexdata.EmailId
      this.phone=sainexdata.phone1
      this.ext=sainexdata.Ext
      this.cdate=sainexdata.cdate
      this.lastname=this.lastname.split(" ");
      if(this.lastname[2]==undefined){
        this.firstname=this.lastname[0]
        this.lastname=this.lastname[1]
        }else{
        this.firstname=this.lastname[0]+" "+this.lastname[1]
        this.lastname=this.lastname[2]
        } 
        var object={firstname:this.firstname,lastname:this.lastname,
                   companyname:this.sainexcompanyname,bdmname:this.sainexbdmname,
                   designation:this.designation,emailId:this.emailId,
                   phone:this.phone,ext:this.ext,cdate:this.cdate,
                   notes:this.textbox1,marketing:this.textbox2}
      //alert(JSON.stringify(object))
      this.rs.sendToSainex(object).subscribe(dt=>{
        
      })
    }
    
  //   checkBox
  //   checkSelected(label: string) {
  //     this.checkBox.forEach(x => {
  //         if(x.label !== label) {
  //             x.checked = !x.checked
  //         }
  //     })
  //  }
     
    onChange(data){
      //alert(JSON.stringify(data))
      this.dropdownstatus=data
      this.contactid=this.dropdownstatus.ID
      this.contactlastname=this.dropdownstatus.FullName
      this.contactbdmname=this.dropdownstatus.BDMName
      this.contactcompanyname=this.dropdownstatus.CompanyName
      this.contactlastname=this.contactlastname.split(" ");
      if(this.contactlastname[2]==undefined){
        this.contactfirstname=this.contactlastname[0]
        this.contactlastname=this.contactlastname[1]
        }else{
        this.contactfirstname=this.contactlastname[0]+" "+this.contactlastname[1]
        this.contactlastname=this.contactlastname[2]
        } 
        this.contactstatus=this.dropdownstatus.status.value
        var obj ={id:this.contactid,firstname:this.contactfirstname,lastname:this.contactlastname,status:this.contactstatus,bdmname:this.contactbdmname,companyname:this.contactcompanyname}
        //alert(JSON.stringify(obj))
        this.rs.changeStatusDnc(obj).subscribe(dt=>{
          //alert("Status Updated")
          this.fungetcompany()
          this.fungetleads()
        })
    }

    lesdstatus
    leadstatusvalue
    leadsid
    leadslastname
    leadsfirstname
    leadsbdmname
    leadscompanyname
    leadsdata
    onChangeleads(status){
      this.lesdstatus=status
      this.leadsid=this.lesdstatus.ID
      this.leadslastname=this.lesdstatus.FullName
      this.leadsbdmname=this.lesdstatus.BDMName
      this.leadscompanyname=this.lesdstatus.CompanyName
      this.leadslastname=this.leadslastname.split(" ");
      if(this.leadslastname[2]==undefined){
        this.leadsfirstname=this.leadslastname[0]
        this.leadslastname=this.leadslastname[1]
        }else{
        this.leadsfirstname=this.leadslastname[0]+" "+this.leadslastname[1]
        this.leadslastname=this.leadslastname[2]
        } 
        this.leadstatusvalue=this.lesdstatus.status.value
        var obj ={id:this.leadsid,firstname:this.leadsfirstname,lastname:this.leadslastname,status:this.leadstatusvalue,bdmname:this.leadsbdmname,companyname:this.leadscompanyname}
        this.rs.changeStatusleads(obj).subscribe(dt=>{
          this.fungetcompany()
          this.fungetleads()
        })
    }

    userLogout(){
      localStorage.clear(),
      location.href="http://localhost:4200"
      this.rt.navigateByUrl("")
    }

     fungetcompany(){
      var company={companyname:this.companyname,bdmname:this.bdmname}
       this.rs.getcompany(company).subscribe(dt=>{
         this.contacts=dt
         this.contacts=this.contacts.recordsets[0]
        //  this.contacts = Math.max.apply(Math, this.contacts.map(o=>{ return o.cdate}))
         //  this.contacts=this.contacts.sort((a,b) => a.cdate.rendered.localeCompare(b.cdate.rendered));
         //this.contacts=this.contacts.sort((a,b)=>a.cdate.rendered > b.cdate.rendered)
         this.contacts= _.uniqBy(this.contacts, 'FullName','Designation','phone1','Ext','EmailId','cdate'); 
         //  this.contacts.push({ text: "DNC", value: "DNC" })
         //alert(JSON.stringify(this.contacts))
       })
     }

    fungetleads(){
      var leads={companyname:this.companyname,bdmname:this.bdmname}
      this.rs.getleads(leads).subscribe(dt=>{
        this.leads=dt
        this.leads=this.leads.recordsets[0]
        this.leads= _.uniqBy(this.leads,'Position','Location','Status','linkedin','jobDescription','Ctype','time_zone');
        for(var i=0;i<=this.leads.length;i++){
          if(this.leads[i].Status== null || this.leads[i].Status== 'NULL' || this.leads[i].Status== ''){
            this.leads[i].Status="Select item..."
          }
        }
      })  
    }

  }
